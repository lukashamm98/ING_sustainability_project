## Preprocessing 

A collection of sustainability report preprocessing.

### Prerequisites

Recommended Python version of 3.7. Activate a Python environment of your choice (e.g. Conda or venv) and install required packages as follows.

```bash
pip install -r requirements.txt
```

### Data requirement

This project can process either a collection of PDF files (raw sustainability reports) or preprocessed data in CSV format. All files for processing have to be stored in the same directory like following.

```
- input_dir
  - 1.pdf
  - 2.pdf
  - 3.pdf
  - ...
```

If there are any subdirectories inside, their content will not be picked by our scripts.


### Run PDF -> CSV

To preprocess PDF files by converting them into CSV files which each line represents a text block, run the following command.

```bash
python3 -m processor.run -m pdf2csv -i <INPUT_PDF_DIR> -o <OUTPUT_CSV_DIR>
```

Each input file will be preprocessed and written to a CSV file in OUTPUT_DIR with the same name as input (e.g. 123.csv for 123.pdf). The schema of the output CSV is defined as follows.

- page : zero-based page number
- priority : normalised percentile of the block size, value between 0-1, larger means bigger text
- content : text content (block)

Note that the script assumes UTF-8 encoding.

### Run CSV -> Doc2Vec 

After we have CSV files from previous step, we can convert them into Doc2Vec embeddings.

```bash
python3 -m processor.run -m csv2vec -i <INPUT_CSV_DIR> -o <OUTPUT_MODEL_DIR> --model <MODEL_FILENAME>
```


